document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.getElementById('nav-toggle');
  const nav = document.getElementById('nav');
  const links = document.querySelectorAll('.site-nav a');


  navToggle.addEventListener('click', () => {
    nav.classList.toggle('open');
  });


  window.addEventListener('scroll', () => {
    let fromTop = window.scrollY + 100;
    links.forEach(link => {
      let section = document.querySelector(link.hash);
      if (section && section.offsetTop <= fromTop && section.offsetTop + section.offsetHeight > fromTop) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  });


  links.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      document.querySelector(link.getAttribute('href')).scrollIntoView({ behavior: 'smooth' });
      nav.classList.remove('open');
    });
  });


  const form = document.getElementById('contactForm');
  const result = document.getElementById('formResult');
  form.addEventListener('submit', e => {
    e.preventDefault();
    const name = document.getElementById('name').value.trim();
    const contact = document.getElementById('contactInfo').value.trim();
    const message = document.getElementById('message').value.trim();
    if (!name || !contact || !message) {
      result.textContent = 'Пожалуйста, заполните все поля.';
      result.style.color = 'red';
      return;
    }
    result.textContent = 'Спасибо! Ваше сообщение успешно отправлено (демо).';
    result.style.color = 'green';
    form.reset();
  });
});


document.addEventListener('DOMContentLoaded', function() {
  const navLinks = document.querySelectorAll('.site-nav a');
  navLinks.forEach(a => {
    const text = a.textContent.trim().toLowerCase();
    let section = null;
    try {
      if (a.hash) section = document.querySelector(a.hash);
    } catch(e){}
    if (!section) {
      const headings = Array.from(document.querySelectorAll('h2'));
      section = headings.find(h => h.textContent.trim().toLowerCase() === text)?.closest('section') || null;
    }
    if (section) {
      const h2 = section.querySelector('h2');
      if (h2) {
        const color = window.getComputedStyle(h2).color;
        a.style.color = color;
      }
    }
  });


  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
      } else {
        entry.target.classList.remove('in-view');
      }
    });
  }, { threshold: 0.15 });

  document.querySelectorAll('.section').forEach(s => observer.observe(s));

  
  const modal = document.getElementById('previewModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalGallery = document.getElementById('modalGallery');
  const modalBack = document.getElementById('modalBack');


  const categoryMap = {
    'logos': [
      'images/logos/logos (1).jpg',
      'images/logos/logos (2).jpg',
      'images/logos/logos (3).jpg',
      'images/logos/logos (4).jpg',
      'images/logos/logos (5).jpg'
    ],
    'posters': [
      'images/posters/posters (1).jpg',
      'images/posters/posters (2).jpg',
      'images/posters/posters (3).jpg',
      'images/posters/posters (4).jpg',
      'images/posters/posters (5).jpg',
      'images/posters/posters (6).jpg',
      'images/posters/posters (7).jpg',
      'images/posters/posters (8).jpg'
    ],
    'misc': [
      'images/misc/misc (1).jpg',
      'images/misc/misc (2).jpg',
      'images/misc/misc (3).jpg',
      'images/misc/misc (4).jpg',
      'images/misc/misc (5).jpg'
    ],
    'photo-restoration': [
      'images/photo-restoration/photo-restoration (1).jpg',
      'images/photo-restoration/photo-restoration (2).jpg',
      'images/photo-restoration/photo-restoration (3).jpg'
    ]
  };

  document.querySelectorAll('.card[data-category]').forEach(card => {
    card.addEventListener('click', () => {
      const cat = card.dataset.category;
      modalTitle.textContent = card.textContent.trim();
      modalGallery.innerHTML = '';const list = categoryMap[cat] || [];
      if (list.length === 0) {
        const p = document.createElement('p');
        p.textContent = 'Пока нет примеров для этой категории.';
        modalGallery.appendChild(p);
      } else {
        list.forEach(src => {
          const img = document.createElement('img');
          img.src = src;
          img.alt = `${modalTitle.textContent} — пример`;
          modalGallery.appendChild(img);
        });
      }

      modal.setAttribute('aria-hidden', 'false');
      document.body.style.overflow = 'hidden';
    });
  });

  modalBack.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  function closeModal() {
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
});

document.addEventListener("DOMContentLoaded", function() {
  const galleryImgs = document.querySelectorAll(".gallery img");
  if (galleryImgs.length) {
    galleryImgs.forEach(img => {
      img.style.transition = "transform 0.25s ease";
      img.addEventListener("click", () => {
        if (img.classList.contains("zoomed")) {
          img.classList.remove("zoomed");
          img.style.transform = "";
        } else {
          img.classList.add("zoomed");
          img.style.transform = "scale(1.05)";
        }
      });
    });
  }
  const form = document.querySelector("form");
  if (form) {
    form.addEventListener("submit", function(e) {
      e.preventDefault();
      alert("Форма отправлена (заглушка).");
      form.reset();
    });
  }
});
document.addEventListener("gesturestart", function(e) {
  e.preventDefault();
});